package ec.edu.ups.reportes.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
