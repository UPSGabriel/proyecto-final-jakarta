package ec.edu.ups.reportes.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReportesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportesApiApplication.class, args);
	}

}
